<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\SliderController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\subCategoryController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AddressController;
use App\Http\Controllers\UniteController;
use App\Http\Controllers\VarietyController;
use App\Http\Controllers\CommandeController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/register', [RegisterController::class, 'SignUp']);
Route::post('/login', [RegisterController::class, 'LogIn']);
Route::post('/phone', [RegisterController::class, 'Phone']);


Route::post('/profil', [UserController::class, 'getProfil']);
Route::put('/profil', [UserController::class, 'updateProfil']);
Route::post('/photo', [UserController::class, 'updateProfilImg']);


// Route::post('/telephone', [RegisterController::class, 'phone']);

Route::post('/post/category', [CategoryController::class, 'addCategory']);
Route::put('/update/category', [CategoryController::class, 'updateCategory']);
Route::get('/get/categories', [CategoryController::class, 'getCategories']);


Route::get('category/{id}/sliders', [CategoryController::class, 'getCategorySliders']);
Route::get('category/{id}/products', [CategoryController::class, 'getCategoryProducts']);


Route::post('/post/product', [ProductController::class, 'addProduct']);
Route::post('/product/img', [ProductController::class, 'addProductImg']);
Route::post('/productById', [ProductController::class, 'getProductById']);
Route::post('/similarProducts', [ProductController::class, 'getSimilarProduct']);
Route::post('/searchProducts', [ProductController::class, 'searchProduct']);



Route::post('/order', [CommandeController::class, 'saveCommande']);
Route::post('/my_order', [CommandeController::class, 'getUserCommand']);
Route::post('/orderDetail', [CommandeController::class, 'getCommandDetail']);


Route::post('/variety', [VarietyController::class, 'addVarietyType']);
Route::put('/variety', [VarietyController::class, 'updateVarietyType']);
Route::post('/productVariety', [VarietyController::class, 'addProductVariety']);
Route::put('/productVariety', [VarietyController::class, 'updateProductVariety']);


Route::post('/unite', [UniteController::class, 'addUnite']);
Route::put('/unite', [UniteController::class, 'updateUnite']);
Route::get('/unite', [UniteController::class, 'getUnite']);


Route::post('post/address', [AddressController::class, 'addAddress']);
Route::put('update/address', [AddressController::class, 'updateAddress']);
// Route::get('get/categories', [CategoryController::class, 'getCategories']);


Route::post('/subCategory', [subCategoryController::class, 'addSubCategory']);
Route::put('/subCategory', [subCategoryController::class, 'updateSubCategory']);
Route::get('category/{id}/subCategories', [subCategoryController::class, 'getSubCategories']);


Route::get('/sliders', [SliderController::class, 'getSliders']);
Route::post('/sliders', [SliderController::class, 'addSlider']);
Route::post('update/slider', [SliderController::class, 'updateSlider']);

