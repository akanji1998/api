<?php

namespace App\Http\Controllers;

use App\Models\user;
use App\Models\address;
use Illuminate\Http\Request;
use Validator;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function getProfil(Request $request)
    {
        $validator = validator::make(
            $request->all(),
            [
                'accessToken' => 'required|max:250',

            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();

        $profile = User::where('access_token', $validated['accessToken'])->first();

        if (empty($profile)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "profil not found",],
                400
            );
        }

        return response()->json(
            [
                "code" => 200,
                "status" => "success",
                "msg" => "profil fetched successfully",
                "data" => $profile,
            ],
            200
        );

    }

    /**
     * Store a newly created resource in storage.
     */
    public function updateProfil(Request $request)
    {
        $validator = validator::make(
            $request->all(),
            [
                'access_token' => 'required|max:250',
                'first_name' => 'required|max:250',
                'last_name' => 'required|max:250',
                'email' => 'required|email',
                'phone' => 'required|numeric',
                'phone_code' => 'required|string',
                'country_code' => 'required|string',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();
        $profile = User::where('access_token', $validated['access_token'])->first();
        if (empty($profile)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "profil not found",],
                400
            );
        }

        $profile->first_name = $validated['first_name'];
        $profile->last_name = $validated['last_name'];
        $profile->email = $validated['email'];
        $profile->phone = $validated['phone'];
        $profile->phone_code = $validated['phone_code'];
        $profile->country_code = $validated['country_code'];

        if ($profile->save()) {
            $updatedProfile = User::where('access_token', $profile->access_token)->first();
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "profil updated succesfully",
                    "data" => $updatedProfile,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while updating the category",
                ],
                400
            );
        }


    }

    public function updateProfilImg(Request $request)
    {
        $validator = validator::make(
            $request->all(),
            [
                'accessToken' => 'required|max:250',
                'photo' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            ]
        );

        // Store the file in storage/app/public/photos directory
        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }


        $validated = $validator->Validated();
        $path = $request->file('photo')->store('photos', 'public');

        $profile = User::where('access_token', $validated['accessToken'])->first();
        if (empty($profile)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "profil not found",],
                400
            );
        }

        $profile->image_url = asset('storage/' . $path);

        if ($profile->save()) {
            $updatedProfile = User::where('access_token', $profile->access_token)->first();
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "profil updated succesfully",
                    "data" => $updatedProfile,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while updating the category",
                ],
                400
            );
        }


    }

    
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, user $user)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(user $user)
    {
        //
    }
}
