<?php

namespace App\Http\Controllers;

use App\Models\unite;
use Illuminate\Http\Request;
use Validator;

class UniteController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function addUnite(Request $request)
    {
        $validator = validator::make(
            $request->all(),
            [
                'uniteName' => 'required|string',
                'uniteSigle' => 'required|string',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }
        $validated = $validator->Validated();

        $isUniteExist = Unite::where('unite_name', $validated['uniteName'])
            ->orWhere('unite_sigle', $validated['uniteSigle'])
            ->first();

        if (!empty($isUniteExist)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "l'unité ou l'abrégiation est déjà utilisé",],
                400
            );
        }

        $unite = new unite();
        $unite->unite_name = $validated['uniteName'];
        $unite->unite_sigle = $validated['uniteSigle'];

        if ($unite->save()) {
            $insertedunite = unite::latest('id')->first();
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "unite registered succesfully",
                    "data" => $insertedunite,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while registering the unite",
                ],
                400
            );
        }
    }

    public function updateUnite(Request $request)
    {
        //
        $validator = validator::make(
            $request->all(),
            [

                'id' => 'required|integer',
                "uniteName" => 'required|string',
                "uniteSigle" => 'required|string',

            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();


        $unite = unite::where('id', $validated['id'])->first();
        if (empty($unite)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "unite not found"],
                400
            );
        }

        $existingUniteWithSameName = Unite::find($validated['id'])
        ->where('unite_name', $validated['uniteName'])
            ->orwhere('unite_sigle', $validated['uniteSigle'])->first();

        if (!empty($existingUniteWithSameName)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "unite name already used"],
                400
            );
        }



        $unite->unite_name = $validated['uniteName'];
        $unite->unite_sigle = $validated['uniteSigle'];


        if ($unite->save()) {
            $updatedunite= unite::where('id', $unite->id)->first();
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "category updated succesfully",
                    "data" => $updatedunite,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while updating the category",
                ],
                400
            );
        }

    }

    public function getUnite()
    {
        $unite = unite::all();
        return response()->json(
            [
                "code" => 200,
                "status" => "success",
                "msg" => "unite fetched successfully",
                "data" => $unite,
            ],
            200
        );
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, unite $unite)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(unite $unite)
    {
        //
    }
}
