<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\user;
use App\Models\telephone;
use Validator;

class RegisterController extends Controller
{
    public function SignUp(Request $request)
    {
        $validator = validator::make(
            $request->all(),
            [
                'firstName' => 'required|max:250',
                'lastName' => 'required|max:250',
                'countryCode' => 'required|string',
                'phoneCode' => 'required|integer',
                'phone' => 'required|numeric',
                'email' => 'required|email',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();

        $existUser = User::where('phone', $validated['phone'])
            ->orWhere('email', $validated['email'])
            ->first();

        if (empty ($existUser)) {
            $user = new user;
            $user->first_name = $validated['firstName'];
            $user->last_name = $validated['lastName'];
            $user->country_code = $validated['countryCode'];
            $user->phone_code = $validated['phoneCode'];
            $user->phone = $validated['phone'];
            $user->email = $validated['email'];
            $user->access_token = md5(uniqid() . rand(1000, 9999));
            $user->save();

            $inserteduser = User::latest('id')
                ->select('id', 'first_name', 'last_name', 'phone_code', 'country_code', 'email', 'phone', 'image_url', 'access_token', 'created_at', 'updated_at')
                ->first();

            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "user registered succesfully",
                    "data" => $inserteduser,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "the phone number or email is already used",
                ],
                400
            );
        }
    }

    public function LogIn(Request $request)
    {

        $validator = validator::make(
            $request->all(),
            [

                'phoneCode' => 'required|integer',
                'phone' => 'required|numeric',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();

        $existUser = User::where('phone_code', $validated['phoneCode'])
            ->Where('phone', $validated['phone'])
            ->select('id', 'first_name', 'last_name', 'phone_code', 'country_code', 'phone', 'image_url', 'access_token', 'created_at', 'updated_at')
            ->first();

        if (!empty ($existUser)) {

            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "data" => $existUser
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "le numéro n'est associé à aucun compte",
                ],
                400
            );
        }
    }

    public function Phone(Request $request)
    {
        $validator = validator::make(
            $request->all(),
            [
                // 'accessToken' => 'required',
                'fcmToken' => 'required',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();
        // $user = User::where('access_token',$validated['accessToken'])->first();

        // if (empty($user)) {
        //     return response()->json(
        //         [
        //             "code" => 400,
        //             "status" => "error",
        //             "msg" => "acces token invalid",
        //         ],
        //         400
        //     );
        // }

        $phone = new telephone();
        $phone->fcm_token = $validated['fcmToken'];
        // $phone->user_id = $user->id;

        if ($phone->save()) {
            $insertedPhone = telephone::latest('id')->first();
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "phone inserted succesfully ",
                    "data" => $insertedPhone,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while registering the phone",
                ],
                400
            );
        }
    }
}
