<?php

namespace App\Http\Controllers;

use App\Models\Commande;
use Illuminate\Http\Request;
use Validator;
use Illuminate\Validation\Rule;
use App\Models\user;
use App\Models\product;
use App\Models\category;
use App\Models\unite;
use App\Models\sub_category;
use App\Models\product_variety;
use App\Models\Statut;
use Kreait\Firebase\Factory;
use Kreait\Firebase\Messaging\CloudMessage;

use App\Models\product_image;
use App\Models\variety;

class CommandeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function saveCommande(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'access_token' => 'required|exists:users,access_token',
            'order' => 'required|array',
            'order.*.product_id' => 'required|exists:products,uuid|distinct',
            'order.*.variety_id' => 'required|exists:product_varieties,id|max:250',
            'order.*.qty' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                "code" => 400,
                "status" => "error",
                "msg" => $validator->messages()->first()
            ], 400);
        }

        // Validation réussie, traiter les données ici
        $validatedData = $validator->validated();

        // Maintenant vous pouvez accéder à vos données validées de cette manière :
        $orders = $validatedData['order'];

        $uniqId = uniqid();
        $user = User::where('access_token', $validatedData['access_token'])->first();

        foreach ($orders as $order) {
            // Traitez chaque commande ici
            $command = new Commande();
            $product = Product::where('uuid', $order['product_id'])->first();
            $qty = $order['qty'];
            $variety_id = $order['variety_id'];

            $command->commande_id = $uniqId;
            $command->product_id = $product->uuid;
            $command->product_variety_id = $variety_id;
            $command->product_qty = $qty;
            $command->product_unit_price = $product->price;
            $command->product_total_price = $product->price * $qty;
            $command->user_id = $user->id;
            $command->statut_id = 1;

            $command->save();
        }

        // $firebase = (new Factory)
        //     ->withServiceAccount(__DIR__ . '/../../config/firebase_credentials.json');

        // $messaging = $firebase->createMessaging();
        

        // $message = CloudMessage::fromArray([
        //     'notification' => [
        //         'title' => 'Hello from Firebase!',
        //         'body' => 'This is a test notification.'
        //     ],
        //     'topic' => 'global'
        // ]);

        // $messaging->send($message);

        return response()->json(
            [
                "code" => 200,
                "status" => "success",
                "msg" => "Commande successfully",
            ],
            200
        );

    }

    /**
     * Store a newly created resource in storage.
     */
    public function getUserCommand(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'access_token' => 'required|exists:users,access_token',

        ]);

        if ($validator->fails()) {
            return response()->json([
                "code" => 400,
                "status" => "error",
                "msg" => $validator->messages()->first()
            ], 400);
        }

        // Validation réussie, traiter les données ici
        $validatedData = $validator->validated();

        $user = User::where('access_token', $validatedData['access_token'])->first();

        $commandes = Commande::where('user_id', $user->id)->get();

        foreach ($commandes as $commande) {
            $product = Product::where('uuid', $commande->product_id)->first();
            $statut = Statut::where('id', $commande->statut_id)->first();
            $product["img_url"] = product_image::where("product_id", "$product->uuid")->get();
            $product["unite"] = unite::where("id", "$product->unite_id")->first();
            $product["category"] = category::where("id", "$product->category_id")->first();
            $product["sub_category"] = sub_category::where("id", "$product->sub_category_id")->first();
            $varietyGroup = product_variety::All()->where("product_id", "$product->uuid")
                ->groupBy(("variety_id"));
            $varity = [];
            foreach ($varietyGroup as $key => $value) {
                $type = variety::select(['type'])->where("id", "$key")->first();
                $varity[$type['type']] = $value;
            }
            $product["varieties"] = $varity;

            $commande->statut = $statut;
            $commande->products = $product;
        }

        return response()->json(
            [
                "code" => 200,
                "status" => "success",
                "msg" => "Commande successfully",
                "data" => $commandes
            ],
            200
        );
    }


    public function getCommandDetail(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'access_token' => 'required|exists:users,access_token',
            'command_id' => 'required|exists:commandes,commande_id',
        ]);

        if ($validator->fails()) {
            return response()->json([
                "code" => 400,
                "status" => "error",
                "msg" => $validator->messages()->first()
            ], 400);
        }

        // Validation réussie, traiter les données ici
        $validatedData = $validator->validated();

        $user = User::where('access_token', $validatedData['access_token'])->first();

        $commande = Commande::where('user_id', $user->id)->where('commande_id', $validatedData['command_id'])->
            first();
        $commandes = Commande::where('user_id', $user->id)->where('commande_id', $validatedData['command_id'])->
            get();
        $nbr_commande = Commande::where('user_id', $user->id)->where('commande_id', $validatedData['command_id'])->
            count();
        $totalAmount = Commande::where('user_id', $user->id)->where('commande_id', $validatedData['command_id'])->
            sum('product_total_price');
        $commandeProducts = [];



        foreach ($commandes as $commande) {
            $product = Product::where('uuid', $commande->product_id)->first();
            $statut = Statut::where('id', $commande->statut_id)->first();
            $product["img_url"] = product_image::where("product_id", "$product->uuid")->get();
            $product["unite"] = unite::where("id", "$product->unite_id")->first();
            $product["category"] = category::where("id", "$product->category_id")->first();
            $product["sub_category"] = sub_category::where("id", "$product->sub_category_id")->first();
            $varietyGroup = product_variety::All()->where("product_id", "$product->uuid")
                ->groupBy(("variety_id"));
            $varity = [];
            foreach ($varietyGroup as $key => $value) {
                $type = variety::select(['type'])->where("id", "$key")->first();
                $varity[$type['type']] = $value;
            }
            $product["varieties"] = $varity;
            $product["statut"] = $statut;
            $commandeProducts[] = $product;

            // $commande->statut = $statut;
            // $commande->products = $product;
        }


        return response()->json(
            [
                "code" => 200,
                "status" => "success",
                "msg" => "Commande successfully",
                "data" => [
                    "id" => $validatedData['command_id'],
                    "commande_date" => $commande["created_at"],
                    "product_qty" => $nbr_commande,
                    "paiement_mode" => "Mobile money",
                    "total_amount" => $totalAmount,
                    "products" => $commandeProducts
                ]
            ],
            200
        );
    }

    /**
     * Display the specified resource.
     */
    public function show(Commande $commande)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Commande $commande)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Commande $commande)
    {
        //
    }
}
