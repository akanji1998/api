<?php

namespace App\Http\Controllers;

use App\Models\product;
use App\Models\product_variety;
use App\Models\variety;
use Illuminate\Http\Request;
use Validator;

class VarietyController extends Controller
{
    
    public function addVarietyType(Request $request)
    {
        $validator = validator::make(
            $request->all(),
            [
                'variety_type' => 'required|string',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();

        $isVarietyExist = variety::where('type', $validated['variety_type'])->first();

        if (!empty($isVarietyExist)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "variety already exist",],
                400
            );
        }

        $variety = new variety;
        $variety->type = $validated['variety_type'];

        if ($variety->save()) {
            $insertedvariety = variety::latest('id')->first();
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "variety registered succesfully",
                    "data" => $insertedvariety,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while registering the variety",
                ],
                400
            );
        }
    }

  
    public function updateVarietyType(Request $request)
    {
        //
        $validator = validator::make(
            $request->all(),
            [

                'id' => 'required|integer',
                'variety_type' => 'required|string',

            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();


        $variety_type = variety::where('id', $validated['id'])->first();

        if (empty($variety_type)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "variety type not found"],
                400
            );
        }

        $existingType = variety::where('type', $validated['variety_type'])
            ->where('id', '!=', $validated['id'])->first();

        if (!empty($existingType)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "variety type already used"],
                400
            );
        }



        $variety_type->type = $validated['variety_type'];


        if ($variety_type->save()) {
            $updatedVarietyType = variety::where('id', $variety_type->id)->first();
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "variety updated succesfully",
                    "data" => $updatedVarietyType,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while updating the variety",
                ],
                400
            );
        }

    }

    public function addProductVariety(Request $request)
    {
        $validator = validator::make(
            $request->all(),
            [
                'variety_id' => 'required|integer',
                'product_id' => 'required|string',
                'variety_qty' => 'integer',
                'variety_value' => 'required|string',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();

        $isVarietyExist = variety::where('id', $validated['variety_id'])->first();
        $isProductExist = product::where('uuid', $validated['product_id'])->first();

        if (empty($isVarietyExist)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "variety not found",],
                400
            );
        }

        if (empty($isProductExist)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "product not found",],
                400
            );
        }
      
        $productVarity = new product_variety();
        $productVarity->variety_id = $validated['variety_id'];
        $productVarity->product_id = $validated['product_id'];
        $productVarity->qty = $validated['variety_qty'];
        $productVarity->value = $validated['variety_value'];
        

        if ($productVarity->save()) {
            $insertedvariety = product_variety::latest('id')->first();
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "variety registered succesfully",
                    "data" => $insertedvariety,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while registering the variety",
                ],
                400
            );
        }
    }


    public function updateProductVariety(Request $request)
    {
        //
        $validator = validator::make(
            $request->all(),
            [

                'product_variety_id' => 'required|integer',
                'product_id' => 'required|string',
                'variety_id' => 'required|integer',
                'variety_qty' => 'integer',
                'variety_value' => 'required|string',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();

        $isVarietyExist = variety::where('id', $validated['variety_id'])->first();
        $productVarityConcercerned = product_variety::where('id', $validated['product_variety_id'])->first();
        $productConcerned = product_variety::where('product_id', $validated['product_id'])->first();

        if (empty($isVarietyExist)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "variety not found",],
                400
            );
        }

        if (empty($productConcerned)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "product concerned not found",],
                400
            );
        }
        if (empty($productVarityConcercerned)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "product variety concerned not found"],
                400
            );
        }

        $productVarityConcercerned->variety_id = $validated['variety_id'];
        $productVarityConcercerned->qty = $validated['variety_qty'];
        $productVarityConcercerned->value = $validated['variety_value'];

        if ($productVarityConcercerned->save()) {
            $updateProductVariety = product_variety::where('id', $productVarityConcercerned->id)->first();
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "product variety updated succesfully",
                    "data" => $updateProductVariety,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while registering the category",
                ],
                400
            );
        }


    }



    /**
     * Remove the specified resource from storage.
     */
    public function destroy(variety $variety)
    {
        //
    }
}
