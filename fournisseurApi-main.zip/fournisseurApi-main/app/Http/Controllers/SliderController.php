<?php

namespace App\Http\Controllers;

use App\Models\slider;
use App\Models\category;
use Illuminate\Http\Request;
use Validator;

class SliderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function getSliders()
    {
        $sliders = Slider::where("slider_visible", "0")->get();
        foreach ($sliders as $slider) {

            
            $slider["category"] = category::where("id", "$slider->category_id")->first();
            
        }
        // $sliders['category'] = category::find($sliders['category_id']);

        // DB::table("slider_images")->select("idslider_images", "slider_link", "slider_url")->where("visible", "true")->get();
        return response()->json(
            [
                "code" => 200,
                "status" => "success",
                "msg" => "sliders fetched successfully",
                "data" => $sliders,
            ],
            200
        );
    }

    /**
     * Store a newly created resource in storage.
     */
    public function addSlider(Request $request)
    {
        //

        $validator = validator::make(
            $request->all(),
            [
                'categoryId' => 'required|integer',
                'sliderLink' => 'required|string',
                'sliderImgUrl' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
                'isVisible' => 'required|boolean',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();

        $isCategoryExist = category::where('id', $validated['categoryId'])->first();

        if (empty($isCategoryExist)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "L'id de la categorie est incorrect"],
                400
            );
        }

        $path = $request->file('sliderImgUrl')->store('sliders', 'public');

        $slider = new Slider();
        $slider->category_id = $validated['categoryId'];
        $slider->slider_link = $validated['sliderLink'];
        $slider->slider_img_url = asset('storage/' . $path);
        $slider->slider_visible = $validated['isVisible'];


        if ($slider->save()) {
            $insertedSlider = Slider::latest('id')->first();
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "slider registered succesfully",
                    "data" => $insertedSlider,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while registering the category",
                ],
                400
            );
        }


    }


    public function updateSlider(Request $request)
    {
        //
        $validator = validator::make(
            $request->all(),
            [

                'id' => 'required|integer',
                'categoryId' => 'required|integer',
                'sliderLink' => 'required|string',
                'sliderImgUrl' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
                'isVisible' => 'required|boolean',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();


        $slider = Slider::where('id', $validated['id'])->first();

        $isCategoryExist = category::where('id', $validated['categoryId'])->first();

        if (empty($slider)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "Slider does not exist"],
                400
            );
        }

        if (empty($isCategoryExist)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "L'id de la categorie est incorrect"],
                400
            );
        }
        $path = $request->file('sliderImgUrl')->store('sliders', 'public');
        $slider->category_id = $validated['categoryId'];
        $slider->slider_link = $validated['sliderLink'];
        $slider->slider_img_url = asset('storage/' . $path);
        $slider->slider_visible = $validated['isVisible'];

        if ($slider->save()) {
            $insertedSlider = Slider::where('id', $slider->id)->first();
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "slider updated succesfully",
                    "data" => $insertedSlider,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while registering the category",
                ],
                400
            );
        }


    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(slider $slider)
    {
        //
    }
}
