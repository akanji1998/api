<?php

namespace App\Http\Controllers;

use App\Models\address;
use App\Models\user;
use Illuminate\Http\Request;
use Validator;

class AddressController extends Controller
{
   
    /**
     * Store a newly created resource in storage.
     */
    public function addAddress(Request $request)
    {
        $validator = validator::make(
            $request->all(),
            [
                'access_token' => 'required|max:250',
                'lat' => 'required|numeric',
                'long' => 'required|numeric',
                'place' => 'required|string',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();


        $user = User::where('access_token', $validated['access_token'])->first();

        if (empty($user)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "aucun utilisateur n'est associé"],
                400
            );
        }


        $newAdresse = new Address();
        $newAdresse->user_id = $user->id;
        $newAdresse->lat = $validated['lat'];
        $newAdresse->long = $validated['long'];
        $newAdresse->place = $validated['place'];

        if ($newAdresse->save()) {
            $insertAdress = address::latest('id')->first();
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "Adresse Inserted succesfully",
                    "data" => $insertAdress,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while updating the category",
                ],
                400
            );
        }

    }


    public function updateAddress(Request $request)
    {
        $validator = validator::make(
            $request->all(),
            [
                'access_token' => 'required|max:250',
                'id' => 'required|integer',
                'lat' => 'required|numeric',
                'long' => 'required|numeric',
                'place' => 'required|string',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();

        $user = User::where('access_token', $validated['access_token'])->first();

        if (empty($user)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "aucun utilisateur n'est associé"],
                400
            );
        }

        $updateAdresse = address::where('user_id', $user->id)
            ->where('id', $validated['id'])
            ->first();

        if (empty($updateAdresse)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "adresse introuvable n'est associé"],
                400
            );
        }

        $updateAdresse->lat = $validated['lat'];
        $updateAdresse->long = $validated['long'];
        $updateAdresse->place = $validated['place'];

        if ($updateAdresse->save()) {
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "Adresse updated succesfully",
                    "data" => $updateAdresse,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while updating the category",
                ],
                400
            );
        }

    }

}
