<?php

namespace App\Http\Controllers;

use App\Models\category;
use App\Models\product_image;
use Illuminate\Http\Request;
use App\Models\unite;
use App\Models\sub_category;
use App\Models\variety;
use App\Models\product_variety;
use Validator;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function addCategory(Request $request)
    {
        $validator = validator::make(
            $request->all(),
            [
                'category_name' => 'required|string',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }
        $validated = $validator->Validated();

        $isCategoryExist = category::where('category_name', $validated['category_name'])->first();

        if (!empty($isCategoryExist)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "category already exist",],
                400
            );
        }

        $category = new category;
        $category->category_name = $validated['category_name'];

        if ($category->save()) {
            $insertedcategory = Category::latest('id')->select("category_name")->first();
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "category registered succesfully",
                    "data" => $insertedcategory,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while registering the category",
                ],
                400
            );
        }
    }

    public function updateCategory(Request $request)
    {
        //
        $validator = validator::make(
            $request->all(),
            [

                'id' => 'required|integer',
                'categoryName' => 'required|string',

            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();


        $category = Category::where('id', $validated['id'])->first();
        if (empty($category)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "category not found"],
                400
            );
        }

        $existingCategoryWithSameName = Category::where('category_name', $validated['categoryName'])
            ->where('id', '!=', $validated['id'])->first();

        if (!empty($existingCategoryWithSameName)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "Category name already used"],
                400
            );
        }



        $category->category_name = $validated['categoryName'];


        if ($category->save()) {
            $updatedcategory = Category::where('category_name', $category->category_name)->first();
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "category updated succesfully",
                    "data" => $updatedcategory,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while updating the category",
                ],
                400
            );
        }

    }

    public function getCategories()
    {
        $categories = category::all();
        return response()->json(
            [
                "code" => 200,
                "status" => "success",
                "msg" => "categories fetched successfully",
                "data" => $categories,
            ],
            200
        );
    }

    public function getCategorySliders(Request $request)
    {
        $categoryId = $request->route()->parameter('id');
        if (!is_numeric($categoryId)) {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "Make sure ref is numeric and exists",
                ],
                400
            );
        }

        $isCategoryExist = category::where('id', $categoryId)->first();

        if (empty($isCategoryExist)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "category not found",],
                400
            );
        }

        $sliders = Category::find($categoryId)->sliders;
        return response()->json(
            [
                "code" => 200,
                "status" => "success",
                "msg" => "category sliders fetched successfully",
                "data" => $sliders,
            ],
            200
        );
    }

    public function getCategoryProducts(Request $request)
    {
        $categoryId = $request->route()->parameter('id');
        if (!is_numeric($categoryId)) {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "Make sure ref is numeric and exists",
                ],
                400
            );
        }

        $isCategoryExist = category::where('id', $categoryId)->first();

        if (empty($isCategoryExist)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "category not found",],
                400
            );
        }

        $products = category::find($isCategoryExist->id)->product()->get();

        foreach ($products as $product) {

            $product["img_url"] = product_image::where("product_id", "$product->uuid")->get();
            $product["unite"] = unite::where("id", "$product->unite_id")->first();
            $product["category"] = category::where("id", "$product->category_id")->first();
            $product["sub_category"] = sub_category::where("id", "$product->sub_category_id")->first();
            $varietyGroup = product_variety::All()->where("product_id", "$product->uuid")
                ->groupBy(("variety_id"));

            $tempArray = [];
            foreach ($varietyGroup as $key => $value) {
                $type = variety::select(['type'])->where("id", "$key")->first();
                $varity = [];
                $varity["type"] = $type['type'];
                $varity["value"] = $value;
                $tempArray[] = $varity;
            }
            $product["varieties"] = $tempArray;
        }

        $subCategories = category::find($categoryId)->subCategorie()->get();

        return response()->json(
            [
                "code" => 200,
                "status" => "success",
                "msg" => "category products fetched successfully",
                "data" => [
                    "category" => $isCategoryExist,
                    "subCategories" => $subCategories,
                    "products" => $products,
                ],
            ],
            200
        );
    }





    /**
     * Remove the specified resource from storage.
     */
    public function destroy(category $category)
    {
        //
    }
}
