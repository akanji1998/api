<?php

namespace App\Http\Controllers;

use App\Models\product_variety;
use App\Models\review;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\category;
use App\Models\unite;
use App\Models\sub_category;
use App\Models\product;
use App\Models\product_image;
use App\Models\variety;
use Validator;

class ProductController extends Controller
{

    public function addProduct(Request $request)
    {
        $validator = validator::make(
            $request->all(),
            [
                'name' => 'required|max:250',
                'price' => 'required|max:250',
                'description' => 'required|string',
                'brand' => '',
                'qty' => 'required|integer',
                'unite_id' => 'required|integer',
                'category_id' => 'required|integer',
                'sub_category_id' => 'required|integer',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();

        $isUniteExist = Unite::find($validated['unite_id']);

        $isCategoryExist = category::find($validated['category_id']);
        $isSubCategoryExist = category::find($validated['sub_category_id']);

        if (empty($isUniteExist)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "l'unité not found",],
                400
            );
        }

        if (!empty($isCategoryExist)) {
            $isSubcategoryBelongToCategory = sub_category::find($isCategoryExist->id)->category();

            if (empty($isSubcategoryBelongToCategory)) {
                return response()->json(
                    ["code" => 400, "status" => "error", "msg" => "the sub category not belong to categy scope",],
                    400
                );
            }

        } else {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "category not found",],
                400
            );
        }

        if (empty($isSubCategoryExist)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "sub_category not found",],
                400
            );
        }




        $newProduct = new Product();
        $newProduct->uuid = uuid_create();
        $newProduct->name = $validated['name'];
        $newProduct->price = $validated['price'];
        $newProduct->description = $validated['description'];
        $newProduct->brand = $validated['brand'];
        $newProduct->qty = $validated['qty'];
        $newProduct->unite_id = $validated['unite_id'];
        $newProduct->category_id = $validated['category_id'];
        $newProduct->sub_category_id = $validated['sub_category_id'];

        if ($newProduct->save()) {
            $insertednewProduct = Product::latest('uuid')->orderBy('name','asc')
                ->get();
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "newProduct registered succesfully",
                    "data" => $insertednewProduct,
                ],  
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "an error occurred while saving new product",
                ],
                400
            );
        }
    }

    public function addProductImg(Request $request)
    {
        //

        $validator = validator::make(
            $request->all(),
            [
                'product_id' => 'required|String',
                'product_img' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();

        $isProductExist = product::where('uuid', $validated['product_id'])->first();

        if (empty($isProductExist)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "product not found"],
                400
            );
        }

        $path = $request->file('product_img')->store('products', 'public');

        $newImg = new product_image();
        $newImg->product_id = $validated['product_id'];
        $newImg->img_url = asset('storage/' . $path);


        if ($newImg->save()) {
            $insertednewImg = product_image::latest('id')->first();
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "newImg registered succesfully",
                    "data" => $insertednewImg,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while registering the img",
                ],
                400
            );
        }


    }

    public function getProductById(Request $request)
    {
        $validator = validator::make(
            $request->all(),
            [
                'id' => 'required|String',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();

        $product = product::where('uuid', $validated['id'])->first();
        if (empty($product)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "product not found"],
                400
            );
        }

        // $totalMark =

        $product["img_url"] = product_image::where("product_id", "$product->uuid")->get();
        $product["unite"] = unite::where("id", "$product->unite_id")->first();
        $product["category"] = category::where("id", "$product->category_id")->first();
        $product["sub_category"] = sub_category::where("id", "$product->sub_category_id")->first();
        $varietyGroup = product_variety::All()->where("product_id", "$product->uuid")
            ->groupBy(("variety_id"));

        $tempArray = [];
        foreach ($varietyGroup as $key => $value) {
            $type = variety::select(['type'])->where("id", "$key")->first();
            $varity = [];
            $varity["type"] = $type['type'];
            $varity["value"] = $value;
            $tempArray[] = $varity;
        }
        $product["varieties"] = $tempArray;

        return response()->json(
            [
                "code" => 200,
                "status" => "success",
                "msg" => "categories fetched successfully",
                "data" => $product,
            ],
            200
        );
    }

    public function getSimilarProduct(Request $request)
    {
        $validator = validator::make(
            $request->all(),
            [
                'category_id' => 'required|integer',
                'sub_category_id' => 'required|integer',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();

        $products = product::where('category_id', $validated['category_id'])
            ->orwhere('sub_category_id', $validated['sub_category_id'])
            ->get();

        if (empty($products)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "product not found"],
                400
            );
        }

        $similarProducts = [];
        foreach ($products as $product) {

            $product["img_url"] = product_image::where("product_id", "$product->uuid")->get();
            $product["unite"] = unite::where("id", "$product->unite_id")->first();
            $product["category"] = category::where("id", "$product->category_id")->first();
            $product["sub_category"] = sub_category::where("id", "$product->sub_category_id")->first();
            $varietyGroup = product_variety::All()->where("product_id", "$product->uuid")
                ->groupBy(("variety_id"));
            $varity = [];
            foreach ($varietyGroup as $key => $value) {
                $type = variety::select(['type'])->where("id", "$key")->first();
                $varity[$type['type']] = $value;
            }
            $product["varieties"] = $varity;
            $similarProducts[] = $product;
        }

        return response()->json(
            [
                "code" => 200,
                "status" => "success",
                "msg" => "categories fetched successfully",
                "data" => $similarProducts,
            ],
            200
        );
    }

    public function searchProduct(Request $request)
    {
        $validator = validator::make(
            $request->all(),
            [
                'words' => 'required|string',
            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();
        $searchWords = $validated['words'];
        $products = product::where('name', 'LIKE', "%{$searchWords}%")
            ->orWhere('description', 'LIKE', "%{$searchWords}%")
            ->get();


        if (empty($products)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "product not found"],
                400
            );
        }

        $similarProducts = [];
        foreach ($products as $product) {

            $product["img_url"] = product_image::where("product_id", "$product->uuid")->get();
            $product["unite"] = unite::where("id", "$product->unite_id")->first();
            $product["category"] = category::where("id", "$product->category_id")->first();
            $product["sub_category"] = sub_category::where("id", "$product->sub_category_id")->first();
            $varietyGroup = product_variety::All()->where("product_id", "$product->uuid")
                ->groupBy(("variety_id"));
            $varity = [];
            foreach ($varietyGroup as $key => $value) {
                $type = variety::select(['type'])->where("id", "$key")->first();
                $varity[$type['type']] = $value;
            }
            $product["varieties"] = $varity;
            $similarProducts[] = $product;
        }

        return response()->json(
            [
                "code" => 200,
                "status" => "success",
                "msg" => "categories fetched successfully",
                "data" => $similarProducts,
            ],
            200
        );
    }

}
