<?php

namespace App\Http\Controllers;

use App\Models\sub_category;
use App\Models\category;
use Illuminate\Http\Request;
use Validator;

class subCategoryController extends Controller
{
    public function addSubCategory(Request $request)
    {

        $validator = validator::make(
            $request->all(),
            [
                'categoryId' => 'required|integer',
                'subCategoryName' => 'required|string',

            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();

        $category = category::where('id', $validated['categoryId'])->first();

        if (empty($category)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "category not found"],
                400
            );
        }

        $isSubCategoryExist = sub_category::where('category_id', $validated['categoryId'])
            ->where('sub_category_name', $validated['subCategoryName'])
            ->first();

        if (!empty($isSubCategoryExist)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "sub category already used",],
                400
            );
        }

        $subCategory = new sub_category();
        $subCategory->category_id = $category->id;
        $subCategory->sub_category_name = $validated['subCategoryName'];



        if ($subCategory->save()) {
            $updatedCategory = sub_category::latest('id')->first();
            ;
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "sub category registered succesfully",
                    "data" => $updatedCategory,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while registering the category",
                ],
                400
            );
        }

    }

    public function updateSubCategory(Request $request)
    {
        //
        $validator = validator::make(
            $request->all(),
            [

                'id' => 'required|integer',
                'categoryId' => 'required|integer',
                'subCategoryName' => 'required|string',

            ]
        );

        if ($validator->fails()) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => $validator->messages()->first()],
                400
            );
        }

        $validated = $validator->Validated();


        $subCategory = sub_category::where('id', $validated['id'])->first();

        $isCategoryExist = category::where('id', $validated['categoryId'])->first();

        if (empty($subCategory)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "subCategory does not exist"],
                400
            );
        }

        if (empty($isCategoryExist)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "categorie not found "],
                400
            );
        }



        $isSubCategoryExist = sub_category::where('category_id', $validated['categoryId'])
            ->where('sub_category_name', $validated['subCategoryName'])
            ->first();

        if (!empty($isSubCategoryExist)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "sub category already used",],
                400
            );
        }
        
        $subCategory->category_id = $validated['categoryId'];
        $subCategory->sub_category_name = $validated['subCategoryName'];



        if ($subCategory->save()) {
            $updatedSubCategory = sub_category::where('id', $subCategory->id)->first();
            return response()->json(
                [
                    "code" => 200,
                    "status" => "success",
                    "msg" => "sub Category updated succesfully",
                    "data" => $updatedSubCategory,
                ],
                200
            );
        } else {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "error while registering the category",
                ],
                400
            );
        }

    }

    public function getSubCategories(Request $request)
    {
        $categoryId = $request->route()->parameter('id');
        if (!is_numeric($categoryId)) {
            return response()->json(
                [
                    "code" => 400,
                    "status" => "error",
                    "msg" => "Make sure ref is numeric and exists",
                ],
                400
            );
        }

        $isCategoryExist = category::where('id', $categoryId)->first();

        if (empty($isCategoryExist)) {
            return response()->json(
                ["code" => 400, "status" => "error", "msg" => "category not found",],
                400
            );
        }

        $subCategories = Category::find($categoryId)->sliders;
        return response()->json(
            [
                "code" => 200,
                "status" => "success",
                "msg" => "sub category fetched successfully",
                "data" => $subCategories,
            ],
            200
        );
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(sub_category $sub_category)
    {
        //
    }
}
