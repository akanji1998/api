<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class category extends Model
{
    use HasFactory;

    protected $fillable = [
        'category_name',
    ];

    // Relation avec les lieux favorisés
    public function subCategories(): HasMany
    {
        return $this->HasMany(sub_category::class, 'category_id', )->withTimestamps();
    }


    public function sliders(): HasMany
    {
        return $this->HasMany(slider::class);
    }

    public function subCategorie(): HasMany
    {
        return $this->HasMany(sub_category::class);
    }

    public function product(): HasMany
    {
        return $this->HasMany(product::class);
    }


}
