<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->uuid();
            $table->string("name");
            $table->unsignedBigInteger("price");
            $table->string("description");
            $table->string("brand")->nullable();
            $table->unsignedBigInteger("qty");
            $table->foreignId("unite_id");
            // $table->foreign('unite_id')->references('id')->on('unites')->onDelete('cascade')->onUpdate('cascade');
            $table->foreignId("category_id");
            // $table->foreign('category_id')->references('id')->on('category')->onDelete('cascade')->onUpdate('cascade');
            $table->foreignId("sub_category_id");
            // $table->foreign('sub_category_id')->references('id')->on('sub_category')->onDelete('cascade')->onUpdate('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
